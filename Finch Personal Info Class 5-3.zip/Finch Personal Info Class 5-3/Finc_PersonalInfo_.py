## Rachad Finch
## CSC-221
## 5/3/18

import personal

def main():
    
    per1 = personal.PersonalInfo('Rachad Finch', '815 Isley St', '17', '910-555-5555')
    per2 = personal.PersonalInfo('names', 'addresses', 'ages', 'numbers')
    per3 = personal.PersonalInfo('names', 'addresses', 'ages', 'numbers')

    
    print(per1.get_names)
    print(per1.get_addresses)
    print(per1.get_ages)

main()
