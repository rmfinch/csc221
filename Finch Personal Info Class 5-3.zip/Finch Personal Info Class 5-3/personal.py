## Rachad Finch
## Personal Info Class


class PersonalInfo:
    
    def __init__(self, name, address, age, number):
        self.__names = name
        self.__addresses = address
        self.__age = age
        self.__number = number

    def set_names(self, name):
        self.__names = name

    def set_addresses(self, address):
        self.__addresses = address

    def set_age(self, age):
        self.__ages = age

    def set_numbers(self, number):
        self.__numbers = number

        
    def get_names(self):
        return self.__names

    def get_addresses(self):
        return self.__addresses

    def get_ages(self):
        return self.__age

    def get_numbers(self):
        return self.__number
