## Rachad Finch
## CSC-221
## 5/3/18

import personal



def main():
    
    info = personal.PersonalInfo(addresses, age, number)

    
    info.set_names("Will")
    info.set_addresses("26 Explorer Blvd, Punta Gorda, FL")
    info.set_ages("21")
    info.set_numbers("941-245-0255")

    
    print("Name: ", info.get_names())
    print("Address:", info.get_addresses())
    print("Age:", info.get_ages())
    print("Phone number:", info.get_numbers())
    print

    
    info.set_names("Pat")
    info.set_addresses("26 Explorer, Punta Gorda, FL")
    info.set_ages("28")
    info.set_numbers("941-245-0266")

    
    print("Name:", info.get_names())
    print("Address:", info.get_addresses())
    print("Age:", info.get_ages())
    print("Phone number:", info.get_numbers())
    print 

    
    info.set_names("Motley")
    info.set_addresses("11 Scotland Ave, Edison, NJ")
    info.set_ages("49")
    info.set_numbers("732-709-3409")

    
    print("Name:", info.get_names())
    print("Address:", info.get_addresses())
    print("Age:", info.get_ages())
    print("Phone number:", info.get_numbers())

main()
