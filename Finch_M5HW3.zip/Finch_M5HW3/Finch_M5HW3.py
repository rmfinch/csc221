#Rachad Finch
#5/1/18
#CSC-221

import employee


def main():
    #Create three employee objects
    emp1 = employee.Employee('name', 'id', 'department', 'title')
    emp2 = employee.Employee('name', 'id', 'department', 'title')
    emp3 = employee.Employee('name', 'id', 'department', 'title')

    #create three Employee objects for each attribute
    emp1.set_name('Susan Meyers')
    emp1.set_id('47899')
    emp1.set_department('Accounting')
    emp1.set_title('Vice President')

    emp2.set_name('Mark Jones')
    emp2.set_id('39119')
    emp2.set_department('IT')
    emp2.set_title('Programmer')

    emp3.set_name('Joy Rogersr')
    emp3.set_id('81774')
    emp3.set_department('Manufacturing')
    emp3.set_title('Engineer')

    print()
    print(emp1)
    print()
    print(emp2)
    print()
    print(emp3)


main()
